---
id: "news-accelerometer-network-2025"
title: "Deployment of Strong-Motion Accelerometer Array Across University of Duhok Campus and Strategic Bridges"
title_kurdish: "دانانا تۆڕەکا ئامیرێن پێڤانا عەرد هەژینێ یێن بهێز ل کەمپوسا زانکۆیا دهۆک و پرێن ستراتیجی"
title_arabic: "تركيب شبكة مقاييس التسارع للرصد الزلزالي القوي في حرم جامعة دهوك والجسور الاستراتيجية"
type: "news"
date: "2025-08-01"
author: "SHRU Press Office"
tags: ["Instrumentation", "Accelerograph", "Monitoring", "Campus News"]
status: "published"
featured: true
cover_image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80"
---
# Deployment of Strong-Motion Accelerometer Array Across University of Duhok Campus and Strategic Bridges
> **Abstract:** SHRU has completed phase 1 deployment of three-component digital strong-motion accelerographs (GeoSIG / Kinemetrics) across key civil infrastructure in Duhok to capture real-time ground shaking.

The **Seismic Hazard Resilience Unit (SHRU)** at the University of Duhok College of Engineering announces the operational launch of its dedicated strong-motion monitoring array.

### Installed Stations:
1. **UoD Engineering Central Station (SHRU-01):** Free-field instrument situated on limestone bedrock bedrock at the central campus.
2. **Duhok Ring Road Viaduct Station (SHRU-02):** Pier base and deck sensors monitoring structural vibration and seismic traffic interaction.
3. **Duhok Dam Abutment Station (SHRU-03):** Continuous dynamic telemetry streaming to the SHRU seismic data lab.

Data recorded will be publicly shared in standard miniSEED and SAC formats with academic researchers and emergency management authorities across Iraq and international seismological federations.