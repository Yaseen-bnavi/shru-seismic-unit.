---
id: "announcement-resilience-conference-2025"
title: "Call for Abstracts: 2nd Kurdistan International Conference on Earthquake Engineering & Disaster Resilience (KICEDR-2026)"
title_kurdish: "گەنگەشەیا نڤیسینا ڤەکۆلینان: دووەمین کۆنفرانسێ نێڤدەولەتی یێ کوردستانێ بۆ ئەندازیاریا عەرد هەژینان ٢٠٢٦"
title_arabic: "دعوة لتقديم الأوراق البحثية: المؤتمر الدولي الثاني للهندسة الزلزالية وإدارة الكوارث في كردستان 2026"
type: "announcement"
date: "2025-08-25"
author: "Conference Organizing Committee"
tags: ["Conference", "Call for Papers", "KICEDR", "Events"]
status: "published"
featured: true
cover_image: "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80"
---
# Call for Abstracts: 2nd Kurdistan International Conference on Earthquake Engineering & Disaster Resilience (KICEDR-2026)
> **Abstract:** Hosted by College of Engineering - University of Duhok, bringing together leading researchers from the Middle East, Europe, and North America on seismic hazard mitigation.

### Important Dates
- **Abstract Submission Deadline:** November 15, 2025
- **Notification of Acceptance:** December 20, 2025
- **Full Paper Submission:** February 10, 2026
- **Conference Dates:** April 22–24, 2026

### Conference Themes:
1. Seismic Hazard Assessment & Microzonation in Active Fold Belts
2. Performance-Based Earthquake Engineering (PBEE) for Modern & Heritage Structures
3. Geotechnical Earthquake Engineering & Soil Liquefaction
4. AI and Machine Learning in Post-Disaster Damage Detection & Drone Inspection
5. Community Preparedness and Civil Defense Preparedness Protocols

Accepted peer-reviewed papers will be published in Scopus-indexed conference proceedings.