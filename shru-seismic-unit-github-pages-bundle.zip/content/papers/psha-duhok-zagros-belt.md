---
id: "paper-psha-duhok-2025"
title: "Probabilistic Seismic Hazard Assessment (PSHA) for Duhok Governorate and the Zagros Fold-and-Thrust Belt"
title_kurdish: "هەلسەنگاندنا ئەگەرین مەترسیا عەرد هەژینێ بۆ پارێزگەها دهۆکێ و زنجیرە چیاین زاگرۆس"
title_arabic: "تقييم المخاطر الزلزالية الاحتمالية لمحافظة دهوك وحزام طيات زاجروس"
type: "research-paper"
date: "2025-08-14"
author: "Dr. Hameed B. Navi"
affiliation: "Department of Civil Engineering, University of Duhok"
doi: "10.1016/j.soildyn.2025.108920"
pdf_url: "https://example.com/papers/psha-duhok-2025.pdf"
tags: ["PSHA", "Seismic Hazard", "Duhok", "Zagros Belt", "GMPE", "Civil Engineering"]
status: "published"
featured: true
cover_image: "https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?auto=format&fit=crop&w=1200&q=80"
---
# Probabilistic Seismic Hazard Assessment (PSHA) for Duhok Governorate and the Zagros Fold-and-Thrust Belt
> **Abstract:** This paper presents an updated probabilistic seismic hazard assessment (PSHA) for Duhok Governorate, Northern Iraq. Incorporating newly cataloged regional seismicity from the Bitlis-Zagros Suture Zone and the East Anatolian Fault systems, hazard curves for Peak Ground Acceleration (PGA) and spectral accelerations (T = 0.2s and 1.0s) for 10% and 2% probability of exceedance in 50 years (475-year and 2475-year return periods) are developed using cutting-edge Ground Motion Prediction Equations (GMPEs).

## Abstract
This study establishes a refined **Probabilistic Seismic Hazard Assessment (PSHA)** for the Duhok urban center and surrounding districts within the Kurdistan Region of Iraq. Due to its tectonic positioning proximate to the active convergent boundary of the Arabian and Eurasian plates, reliable seismic hazard zoning is vital for civil infrastructure resilience.

## Tectonic Setting & Seismicity Catalog
The study area is bounded by two prominent tectonic active structures:
1. **The Zagros Fold-and-Thrust Belt (ZFTB)** to the east and south-east.
2. **The Bitlis Suture Zone** and nearby strike-slip branches of the **East Anatolian Fault (EAF)** to the north and north-west.

An updated harmonized earthquake catalog (covering historical events from 1900 to 2025 with $M_w \ge 3.5$) was compiled using records from the Iraqi Seismic Network, Kandilli Observatory (KOERI), and EMSC. Declustering was performed using the Gardner-Knopoff algorithm to eliminate aftershocks and foreshocks.

## Ground Motion Prediction Equations (GMPE)
A weighted logic-tree framework was implemented utilizing three modern Next Generation Attenuation (NGA-West2) models:
* Boore et al. (2014) - Weight: 0.40
* Campbell & Bozorgnia (2014) - Weight: 0.35
* Chiou & Youngs (2014) - Weight: 0.25

$$\ln(Y) = f(M, R, V_{s30}, \text{Fault Type})$$

## Results & Findings
- **475-year return period (10% in 50 years):** Uniform Hazard PGA ranges from **0.16g to 0.24g** across Duhok Governorate.
- **2,475-year return period (2% in 50 years):** Maximum PGA reaches **0.38g** in northern mountainous zones adjacent to active fault segments.
- Recommended design response spectra are formulated for local Site Classes B, C, and D based on $V_{s30}$ geophysical surveys conducted at key urban construction sectors in Duhok city.

## Conclusions & Policy Recommendations
1. Modern structural codes (such as modern updates to the Iraqi Seismic Code and ASCE 7-22) must be strictly enforced for critical infrastructure including hospitals, bridges, and high-occupancy university facilities.
2. Microzonation studies should be expanded for riverbank gravel basins and steep slope areas prone to co-seismic landslides during moderate-to-severe ground shaking.