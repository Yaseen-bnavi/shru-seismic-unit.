---
id: "paper-duhok-dam-seismic-2025"
title: "Seismic Stability and Dynamic Deformation Assessment of Duhok Earthfill Dam Under Maximum Credible Earthquake"
title_kurdish: "هەلسەنگاندنا سەقامگیریا عەرد هەژینێ و شێواندنا دینامیکی یا بەنداڤا دهۆکێ ل بن کارتێکرنا بلندترین عەرد هەژینا پێشبینیکری"
title_arabic: "تقييم الاستقرار الزلزالي والتشوه الديناميكي لسد دهوك الترابي تحت تأثير أقصى زلزال معقول"
type: "research-paper"
date: "2025-04-10"
author: "Prof. Luqman H. Salih"
affiliation: "Water Resources & Geotechnical Engineering, University of Duhok"
doi: "10.1016/j.compgeo.2025.106280"
pdf_url: "https://example.com/papers/duhok-dam-2025.pdf"
tags: ["Earth Dam", "Geotechnical", "Duhok Dam", "FEM Dynamic Analysis", "Liquefaction"]
status: "published"
featured: false
cover_image: "https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=1200&q=80"
---
# Seismic Stability and Dynamic Deformation Assessment of Duhok Earthfill Dam Under Maximum Credible Earthquake
> **Abstract:** Comprehensive 2D finite element dynamic deformation analysis of the Duhok Dam (60m-high zoned earthfill embankment) subjected to simulated M7.2 earthquake scenarios. The analysis evaluates excess pore-water pressure generation, crest settlement, and post-seismic slope safety factors.

## Critical Infrastructure Evaluation
The Duhok Dam is a crucial water storage and flood protection facility located immediately upstream of Duhok city. Evaluating its structural integrity against Maximum Credible Earthquakes (MCE) is a core safety mission of the Seismic Hazard Resilience Unit (SHRU).

### Numerical Soil Model
- Coupled dynamic stress-pore pressure finite element simulation in PLAXIS 2D / FLAC.
- Hardening Soil model with small-strain stiffness (HSsmall) calibrated from in-situ Downhole seismic tests and resonant column lab experiments conducted at the College of Engineering Geotechnical Lab.

### Conclusions
- The calculated permanent crest settlement under the critical MCE ground motion ($PGA = 0.32g$) is estimated at **0.24 m**, which represents less than 4% of the dam's 6.0 m active freeboard.
- No continuous liquefaction zone develops within the compacted clayey core or upstream shell; downstream drainage filter prevents seepage erosion post-shaking.