---
id: "paper-nonlinear-rc-frames-2025"
title: "Nonlinear Dynamic Response of Irregular RC Frame Buildings Under Near-Fault Pulse-Like Ground Motions"
title_kurdish: "بەرسڤدانا دینامیکی نەخێڵی یا ئاڤاهێن هەیکەلی یێن کۆنکریتی ل ژێر شەپۆلێن عەرد هەژینێ یێن نێزیک دەرزیێ"
title_arabic: "الاستجابة الديناميكية غير الخطية للمباني الهيكلية الخرسانية غير المنتظمة تحت تأثير الحركات الأرضية النبضية القريبة من الصدع"
type: "research-paper"
date: "2025-06-20"
author: "Dr. Rezan S. Ahmed"
affiliation: "Department of Civil Engineering, University of Duhok"
doi: "10.1061/(ASCE)ST.1943-541X.0003891"
pdf_url: "https://example.com/papers/rc-frames-near-fault-2025.pdf"
tags: ["Nonlinear Analysis", "RC Buildings", "Near-Fault Pulses", "OpenSees", "Soft-Story"]
status: "published"
featured: true
cover_image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
---
# Nonlinear Dynamic Response of Irregular RC Frame Buildings Under Near-Fault Pulse-Like Ground Motions
> **Abstract:** Near-fault ground motions characterized by long-period velocity pulses impose severe seismic demands on multi-story reinforced concrete (RC) buildings with vertical irregularities. This research analyzes 3D nonlinear time-history response of 6-to-15 story RC frames common in Northern Iraq, proposing modified ductility reduction factors.

## Investigation Overview
Vertical structural irregularities (such as soft-story ground levels for commercial shops and setback geometric offsets) represent a prevalent architectural pattern in newly developing metropolitan zones in Duhok and the wider Kurdistan region. 

This research investigates the performance of these buildings under 40 synthetic and recorded near-fault pulse records exhibiting strong forward-directivity effects.

## Numerical Modeling Framework
- **Platform:** OpenSees (Open System for Earthquake Engineering Simulation) with fiber beam-column elements.
- **Material Models:** Concrete02 (Kent-Scott-Park with linear tension softening) and Steel02 (Giuffré-Menegotto-Pinto).
- **Limit States Checked:** Immediate Occupancy (IO), Life Safety (LS), and Collapse Prevention (CP) under ASCE 41-23.

## Key Outcomes
1. Traditional equivalent static force procedures underestimate inter-story drift demands by up to **44%** at the soft-story level under velocity pulses.
2. Introduction of Buckling-Restrained Braces (BRBs) or corner shear walls reduces top roof displacement by **38%** and eliminates sudden inter-story drift concentration.