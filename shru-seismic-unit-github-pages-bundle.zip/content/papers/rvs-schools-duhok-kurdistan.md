---
id: "paper-rvs-schools-kurdistan"
title: "FEMA P-154 Rapid Visual Screening (RVS) of School Facilities in Duhok Governorate: Risk Ranking and Retrofit Priority Index"
title_kurdish: "پشکنینا بلەز یا بینایی (RVS) بۆ قوتابخانەیێن پارێزگەها دهۆکێ: پلەبەندییا مەترسیێ و پلانێن بهێزکرنێ"
title_arabic: "الفحص البصري السريع لمباني المدارس في محافظة دهوك: تصنيف المخاطر وخطة التدعيم الإنشائي"
type: "technical-report"
date: "2025-02-15"
author: "Seismic Hazard Resilience Unit (SHRU) Technical Committee"
affiliation: "University of Duhok - College of Engineering"
doi: "10.1007/s10518-024-02010-8"
tags: ["RVS", "School Safety", "FEMA P-154", "Structural Screening", "Disaster Mitigation"]
status: "published"
featured: false
cover_image: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=1200&q=80"
---
# FEMA P-154 Rapid Visual Screening (RVS) of School Facilities in Duhok Governorate: Risk Ranking and Retrofit Priority Index
> **Abstract:** Survey and risk scoring of 120 public school buildings in Duhok urban and rural sectors. 18% were identified with seismic vulnerability scores below the FEMA cutoff threshold (S < 2.0), requiring detailed Tier-2 structural engineering evaluation.

## Executive Summary
Schools serve as both critical centers of community assembly and potential emergency shelters in post-disaster scenarios. Under the mandate of the University of Duhok College of Engineering, SHRU deployed engineering field inspection teams to conduct systematic rapid visual screening.

### Methodology
1. Collection of structural drawings, construction year, and soil classification.
2. Identification of basic building types: Concrete Moment Frames (C1), Unreinforced Masonry (URM), and Precast Concrete (PC).
3. Score modifications based on vertical irregularities, plan irregularity, pounding potential, and soil class.

### Key Statistics
- **Total Facilities Inspected:** 120 schools (480 building blocks)
- **Low Vulnerability ($S \ge 2.0$):** 64%
- **Moderate Vulnerability ($1.0 \le S < 2.0$):** 18%
- **High Vulnerability ($S < 1.0$):** 18% (Primarily pre-1995 unreinforced masonry structures with heavy concrete slabs).

### Recommendations
A phased retrofitting guideline with steel jacketing of exterior columns and shotcrete shear wall additions is proposed, with estimated retrofit cost averaging 12-15% of total replacement value.