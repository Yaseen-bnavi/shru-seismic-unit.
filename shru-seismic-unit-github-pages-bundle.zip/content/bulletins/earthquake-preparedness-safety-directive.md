---
id: "bulletin-public-safety-guidelines"
title: "Public Structural Safety Directive: Earthquake Preparedness & Immediate Actions for Residential Buildings"
title_kurdish: "رێنمایێن پاراستنا گشتی: بەرهەڤی و رەوشا بلەز د دەمێ ڕوودانا عەرد هەژینێ دا بۆ ئاڤاهیێن ئاکنجیبوونێ"
title_arabic: "توجيهات السلامة الإنشائية العامة: إرشادات الاستعداد والتصرف الفوري أثناء الزلازل للمباني السكنية"
type: "seismic-bulletin"
date: "2025-07-10"
author: "SHRU Disaster Risk Reduction Team"
tags: ["Safety Guidelines", "Disaster Preparedness", "Public Bulletin", "Kurdish & English"]
status: "published"
featured: false
cover_image: "https://images.unsplash.com/photo-1584467735815-f778f274e296?auto=format&fit=crop&w=1200&q=80"
---
# Public Structural Safety Directive: Earthquake Preparedness & Immediate Actions for Residential Buildings
> **Abstract:** Standard operating safety guidelines for citizens, schools, and building administrators in Duhok and surrounding valleys during and after seismic tremors.

### During the Shaking (Inside a Building):
* **DROP, COVER, and HOLD ON.** Drop to your hands and knees under a sturdy desk or table.
* Stay away from exterior glass windows, unsupported partition walls, and unanchored tall bookshelves.
* **DO NOT** use elevators during or immediately after ground motion.

### After the Shaking Stops:
* Check for natural gas leaks, exposed electrical wiring, and cracked water pipes.
* Visually inspect major reinforced concrete columns and load-bearing walls for diagonal **X-cracks** or spalling concrete.
* If deep structural shear cracks are observed, safely evacuate to designated open assembly zones and notify municipal engineering inspection authorities.

### Emergency Contact:
- **SHRU Seismic Information Line:** +964 (0) 62 722 2260
- **College of Engineering Rapid Response Desk:** shru@uod.ac